#!/bin/sh
taskset -c 0 ./gradlew clean assembleDebug --no-parallel --max-workers=1

