#!/bin/bash
# adb_pair_if_needed.sh
# - Cek apakah ada perangkat ADB via IP.
# - Jika belum ada, minta IP, port koneksi, dan port pairing, lalu jalankan `adb pair`.
export PATH="$PATH:/root/Android/Sdk/platform-tools"
set -u

IP_PORT_PATTERN='([0-9]{1,3}\.){3}[0-9]{1,3}:[0-9]+'

# --- Fungsi validasi IP ---
is_valid_ip() {
    local ip="$1"
    local regex='^([0-9]{1,3}\.){3}[0-9]{1,3}$'
    [[ "$ip" =~ $regex ]] || return 1
    # Validasi tiap oktet 0-255
    local IFS='.'
    local -a oktets=($ip)
    for o in "${oktets[@]}"; do
        (( o >= 0 && o <= 255 )) || return 1
    done
    return 0
}

# --- Fungsi validasi port ---
is_valid_port() {
    local port="$1"
    [[ "$port" =~ ^[0-9]+$ ]] || return 1
    (( port >= 1 && port <= 65535 )) || return 1
    return 0
}

# --- Cek apakah adb tersedia ---
if ! command -v adb >/dev/null 2>&1; then
    echo "❌ Perintah 'adb' tidak ditemukan di PATH." >&2
    exit 2
fi

# --- Cek perangkat ADB via IP ---
devices_output=$(adb devices)
ip_devices=$(echo "$devices_output" | grep -E "$IP_PORT_PATTERN")

if [ -n "$ip_devices" ]; then
    echo "✅ Sudah ada perangkat ADB via IP:"
    echo "$ip_devices"
    exit 0
fi

echo "ℹ️  Belum ada perangkat ADB via IP. Lanjut ke proses pairing."
echo

# --- Minta IP ---
while true; do
    read -r -p "Masukkan IP perangkat (contoh: 192.168.1.10): " ip_addr
    if is_valid_ip "$ip_addr"; then
        break
    fi
    echo "⚠️  IP tidak valid. Coba lagi."
done

# --- Minta port koneksi ---
while true; do
    read -r -p "Masukkan port koneksi ADB (contoh: 5555): " conn_port
    if is_valid_port "$conn_port"; then
        break
    fi
    echo "⚠️  Port tidak valid (1-65535). Coba lagi."
done

# --- Minta port pairing ---
while true; do
    read -r -p "Masukkan port pairing (dari dialog Wireless debugging): " pair_port
    if is_valid_port "$pair_port"; then
        break
    fi
    echo "⚠️  Port tidak valid (1-65535). Coba lagi."
done

echo
echo "🔗 Menjalankan: adb pair ${ip_addr}:${pair_port}"
echo "   (Masukkan kode pairing 6 digit saat diminta)"
echo

# --- Jalankan adb pair ---
if adb pair "${ip_addr}:${pair_port}"; then
    echo
    echo "✅ Pairing berhasil untuk ${ip_addr}:${pair_port}"

    # Opsional: langsung connect setelah pair
    read -r -p "Langsung connect ke ${ip_addr}:${conn_port}? [y/N]: " do_connect
    if [[ "$do_connect" =~ ^[Yy]$ ]]; then
        echo "🔌 Menjalankan: adb connect ${ip_addr}:${conn_port}"
        adb connect "${ip_addr}:${conn_port}"
    fi
else
    echo
    echo "❌ Pairing gagal untuk ${ip_addr}:${pair_port}" >&2
    exit 1
fi
echo "${ip_addr}:${conn_port}" > IP_PORT.txt
